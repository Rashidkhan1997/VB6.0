

select * from Employee1 


)

drop table Employee2


Create table Employee1(
EmpId int IDENTITY (1,1) ,
Empname varchar(20),
Gender varchar(20),
City varchar(20)
)

create PROCEDURE usp_Employee1 
      /* @empid                      int    , */
       @empname                   varchar(20)         , 
       @gender                       varchar(20)     , 
       @city               varchar(20)  
AS 
BEGIN 
     

     INSERT INTO Employee1 
          (                    
            /*EmpId ,*/                     
            Empname                   ,
            Gender                       ,
            City                  
          ) 
     VALUES 
          ( 
            /*@empid ,*/
            @empname ,
            @gender ,
            @city 
          ) 

END 
drop procedure usp_Employee1 

sp_helptext usp_Employee1


CREATE  PROCEDURE usp_Display_Employee1
As
BEGIN
 select * from Employee1 
END
sp_helptext		
use Rashid

Create table Employee2(
AEmpId int IDENTITY (1,1) ,
Fname varchar(20),
Lname varchar(20),
Country varchar(20)
) 

insert into Employee2 values ('a' ,'a','a')
insert into Employee2 values ('b' ,'b','b')
insert into Employee2 values ('c' ,'c','c')
insert into Employee2 values ('d' ,'d','d')
insert into Employee2 values ('e' ,'e','e')
insert into Employee2 values ('f' ,'f','f')
select * from Employee2 


SELECT Employee1.Empname, Employee2.Country
FROM Employee1
INNER JOIN Employee2  ON Employee1.EmpId =Employee2.AEmpId ;


select Empname as Emp, City as [c p]  from Employee1


SELECT Empname, (City + ', ' + Gender)  AS Address
FROM Employee1 ;

select Employee1.City  from Employee1
full outer join  Employee2 on Employee1.EmpId = Employee2.AEmpId 
order by Employee1.City


select a.City, b.Gender from Employee1 a , Employee1 b
where a.EmpId=b.EmpId
order by b.City asc



select EmpName,Gender  from Employee1 
group by Empname 
order by Gender 

CREATE PROCEDURE usp_Login
(
@username VARCHAR(20),  @password VARCHAR(20)
)
AS
BEGIN

SELECT  * FROM Login 
WHERE UserName=@username AND Password =@password
end

select * from Employee1 

sp_helptext usp_Login

drop procedure usp_Login 
 create table Login(
 UserName varchar(20),
 Password varchar(20))
 
 use Rashid 
 select * from Login 
 
 insert into Login values('Rashid','Rashid')
 
 drop table Login 
 
 
 
 create PROCEDURE usp_SignUp 
      /* @empid                      int    , */
       @username                   varchar(20)         , 
       @password                       varchar(20)     
         
AS 
BEGIN 
     

     INSERT INTO Login 
          (                    
            /*EmpId ,*/                     
            UserName                   ,
            Password                       
                              
          ) 
     VALUES 
          ( 
            /*@empid ,*/
            @username ,
            @password  
           
          ) 

END 
sp_helptext usp_SignUp
sp_helptext usp_Login



CREATE PROCEDURE usp_Update

	@username varchar(20),@password varchar(20) ,
@result int OUTPUT AS
Begin 
update Login set UserName=@username,
	Password=@password WHERE UserName = @username;
set @result=1;
select @result;
End


drop procedure usp_Login 

CREATE PROCEDURE usp_Update1

	@username varchar(20),@password varchar(20)
	As 
Begin 
update Login set UserName=@username,
	Password=@password WHERE UserName = @username;
End


CREATE PROCEDURE usp_Delete

	@username varchar(20),@password varchar(20)
	As 
Begin 
Delete from Login where UserName=@username;
End
sp_helptext usp_Login

drop procedure usp_Login 

CREATE PROCEDURE usp_Login
	@username varchar(20),@password varchar(20) 
 AS
Begin 
select UserName,Password  from Login where UserName=@username and
	Password=@password;

End


create procedure usp_Dis 
as 
begin
select * from Login 
end