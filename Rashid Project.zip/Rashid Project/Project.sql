drop table SalaryMst  
create table ClassMst (
CId int unique  IDENTITY (1,1)  ,
Class varchar(50) primary key not null,
BasicPay varchar(50) not null,
Salary varchar(50) not null,
Bonus varchar(50) Null,
Tax varchar(50) null
)
 
                       
alter table EmployeeMst
create table EmployeeMst (
EId int primary key IDENTITY (1,1),
Class varchar(50) foreign key references ClassMst(Class),
Name varchar(20) ,
Address varchar(max),
Salary varchar(20),
Designation varchar(20) null,
Password varchar(20)
)

create table LeaveMst (
LId int primary key IDENTITY (1,1), 
EId integer foreign key references EmployeeMst(EId) not null ,
FromDate date not null,
ToDate date not null,
TDays varchar(20) not null,
Reason varchar(Max),
flag varchar(50) 
)

create table SalaryMst (
SId int IDENTITY (1,1), 
EId int unique foreign key references EmployeeMst(EId),
primary key(SId),
BankAccount varchar(50) ,
Salary varchar(20),
Leave Integer,
Sal_Month integer
)

Create table Admin(
Name varchar(20),
Password varchar(20)
)
insert into Admin values('admin' , 'admin')
insert into Admin values('rashid','rashid')
select * from Admin 

CREATE PROCEDURE usp_Admin
(
@name VARCHAR(20),  @password VARCHAR(20)
)
AS
BEGIN

SELECT  * FROM Admin 
WHERE Name=@name AND Password =@password
end
select * from ClassMst    
insert into ClassMst values('A1',1000,11200,100,100)
insert into ClassMst values('A2',1000,12200,100,100)
insert into ClassMst values('A3',1000,13200,100,100)
=======================Procedure==========================
==========Add==========
drop procedure usp_AddEmployee
alter PROCEDURE usp_AddEmployee 
       @class varchar(50),
       @name varchar(20), 
       @address varchar(max),
       
       @salary varchar(20),
       @designation varchar(20),
       @password varchar(20)    
         
AS 
BEGIN 
     

     INSERT INTO EmployeeMst 
          (                    
             class,                   
            Name  ,
            Address,
            
            Salary,
            Designation,
             Password                      
                              
          ) 
     VALUES 
          ( 
            @class,
            @name ,
            @address,
            
            @salary,
            @designation,
            @password
            
              
           
          ) 

END

 create PROCEDURE usp_AddClass 
 
       @class varchar(50), 
       @basicpay varchar(50),
       @salary varchar(20),
       @bonus varchar(20),
       @tax varchar(20)    
         
AS 
BEGIN 
     

     INSERT INTO ClassMst (
     [Class]
      ,[BasicPay]
      ,[Salary]
      ,[Bonus]
      ,[Tax]
      )
      values  (
       @class, 
      @basicpay,
      @salary,
      @bonus,
      @tax
      
      )
      END
 
 CREATE PROCEDURE usp_DeleteClass
    (@class varchar(50), 
       @basicpay varchar(50),
       @salary varchar(20),
       @bonus varchar(20),
       @tax varchar(20)    )
AS 
BEGIN
    DELETE ClassMst   
    WHERE Class = @class
END    

CREATE PROCEDURE usp_UpdateClass

	(@class varchar(50), 
       @basicpay varchar(50),
       @salary varchar(20),
       @bonus varchar(20),
       @tax varchar(20))
       As
Begin 
update ClassMst  set Class =@class ,BasicPay = @basicpay ,Salary = @salary , Bonus=@bonus ,Tax = @tax 
	 WHERE Class = @class; 
End

create procedure usp_ShowClass

as
Begin
select * from ClassMst 
End
Exec usp_ShowClass 

alter procedure usp_Combo

as
Begin
select Salary  , class from ClassMst 
End

exec usp_Combo 

select * from EmployeeMst  
insert into EmployeeMst values('A1','Rashid Khan','Ganesh Nagar',11200,'Software Associate','Rash')

 CREATE PROCEDURE usp_DeleteEmployee
     @eid int,
     @class varchar(50),
       @name varchar(20), 
       @address varchar(max),
       
       @salary varchar(20),
       @designation varchar(20),
       @password varchar(20)
AS 
BEGIN
    DELETE EmployeeMst   
    WHERE EId = @eid
END  

select * from EmployeeMst 
CREATE PROCEDURE usp_UpdateEmployee
@eid int,
	@class varchar(50),
       @name varchar(20), 
       @address varchar(max),
       
       @salary varchar(20),
       @designation varchar(20),
       @password varchar(20)
       As
Begin 
update EmployeeMst set Class = @class , Name = @name , Address = @address , Salary = @salary ,Designation = @designation ,Password = @password  
	 WHERE EId  = @eid; 
End


create procedure usp_ShowEmployee

as
Begin
select * from EmployeeMst  
End


CREATE PROCEDURE usp_User  
(  
@name VARCHAR(50),  @password VARCHAR(50)  
)  
AS  
BEGIN  
  
SELECT  Name , Password  FROM EmployeeMst    
WHERE Name=@name AND Password =@password  
end

select * from LeaveMst 
alter table LeaveMst Add flag int
sp_helpText usp_Combo
CREATE procedure usp_ViewLeave  
  
as  
Begin  
select * From LeaveMst    
End
alter table LeaveMst add  flag varchar(50)
create PROCEDURE usp_ApplyLeave
 
       @eid int, 
       @fromdate Date,
       @todate Date,
       @tdays int,
       @Reason varchar(50),
       @flag varchar(50)   
         
AS 
BEGIN 
     

     INSERT INTO LeaveMst (
     [EId]
      ,[FromDate]
      ,[ToDate]
      ,[TDays]
      ,[Reason]
      ,[flag]
      )
      values  (
       @eid, 
      @fromdate,
      @todate,
      @tdays ,
      @Reason,
      @flag
      
      )
      END
      drop table LeaveMst 
 select *from LeaveMst 
 select * from EmployeeMst
 insert into LeaveMst values(3,'2/4/2019','4/4/2019',2,'abc','Requested')

 exec usp_ViewLeave 
CREATE PROCEDURE usp_ApproveLeave

	@eid int,
       @fromdate Date, 
       @todate Date,
       
       @tdays int,
       @reason varchar(50),
       @flag varchar(20)
       As
Begin 
update LeaveMst  set  EId  = @eid , ToDate  = @todate  , TDays  = @tdays  ,Reason  = @reason  ,flag = @flag   
	 WHERE EId  = @eid; 
End

 
 
 create procedure usp_ShowUserSalary
@name varchar(50)
as
Begin
select EId , Name , Salary  from EmployeeMst  where Name=@name   
End

exec usp_ShowUserSalary 'Shailesh'
select Name , LId , FromDate , ToDate ,TDays ,Reason , flag  from LeaveMst inner join EmployeeMst on LeaveMst.EId =EmployeeMst.EId 

alter procedure usp_ShowUserLeave
@name varchar(50)
as
Begin
select Name , LId , FromDate , ToDate ,TDays ,Reason , flag  from LeaveMst inner join EmployeeMst on LeaveMst.EId =EmployeeMst.EId 
where Name = @name 
End
exec usp_ShowUserLeave 'Rashid'
select * from ClassMst  
sp_HelpText usp_Combo

alter procedure usp_ViewLeave    
    
as    
Begin    
select Name , LId , FromDate , ToDate ,TDays ,Reason , flag  from LeaveMst inner join EmployeeMst on LeaveMst.EId =EmployeeMst.EId      
End
select * from EmployeeMst   
drop procedure usp_ApproveLeave
sp_helptext usp_ApproveLeave
exec usp_ApproveLeave 1,'3','2/4/2019','4/4/2019','2','Approve'

    alter PROCEDURE usp_ApproveLeave  
  
 @eid int,  
       @fromdate Date,   
       @todate Date,  
         
       @tdays int,  
       @reason varchar(50),  
       @flag varchar(20)  
       As  
Begin   
update LeaveMst  set  EId  = @eid ,FromDate = @fromdate , ToDate  = @todate  , TDays  = @tdays  ,Reason  = @reason  ,flag = @flag     
  WHERE EId  = @eid;   
End
sp_helpText exec usp_ViewLeave
alter procedure usp_ViewLeave      
      
as      
Begin      
select Name , EmployeeMst.EId  , LId , FromDate , ToDate ,TDays ,Reason , flag  from LeaveMst inner join EmployeeMst on LeaveMst.EId =EmployeeMst.EId        
End
use rashid


sp_helptext usp_ViewLeave


alter procedure usp_ViewLeave        
        
as        
Begin        
select Name , EmployeeMst.EId  , LId , FromDate , ToDate ,TDays ,Reason , flag  from LeaveMst inner join EmployeeMst on LeaveMst.EId =EmployeeMst.EId  where flag = 'Requested'        
End
select Name , EmployeeMst.EId  , LId , FromDate , ToDate ,TDays ,Reason , flag  from LeaveMst   inner join EmployeeMst on LeaveMst.EId =EmployeeMst.EId  where flag = 'Requested'
sp_helptext usp_ComboUser
alter procedure usp_ComboUser    
    
as    
Begin    
select EId,Name   from EmployeeMst      
End
select * from ClassMst       
use Rashid
sp_helptext usp_ViewLeave
alter procedure usp_ShowEmployee  
  
as  
Begin  
select EId ,Class ,Name ,Address ,Salary ,Designation from EmployeeMst    
End
 alter procedure usp_ShowUserSalary  
@name varchar(50)  
as  
Begin  
select EId , Name , BasicPay ,Bonus ,Tax ,ClassMst.Salary  from EmployeeMst inner join ClassMst on EmployeeMst.Class = ClassMst.Class  where EmployeeMst.Name=@name     
End

Select * from EmployeeMst     
update LeaveMst set flag ='Requested' where EId = 11
alter PROCEDURE usp_UpdateEmployee  
@eid int,  
 @class varchar(50),  
       @name varchar(20),   
       @address varchar(max),  
         
       @salary varchar(20),  
       @designation varchar(20)  
        
       As  
Begin   
update EmployeeMst set Class = @class , Name = @name , Address = @address , Salary = @salary ,Designation = @designation    
  WHERE EId  = @eid;   
End
CREATE procedure usp_ViewLeave          
          
as          
Begin          
select Name , EmployeeMst.EId  , LId , FromDate , ToDate ,TDays ,Reason , flag  from LeaveMst inner join EmployeeMst on LeaveMst.EId =EmployeeMst.EId  where flag = 'Requested'          
End
use rashid
sp_helpText usp_ID


create procedure usp_ID
as 
begin
select  IDENT_CURRENT('EmployeeMst')+  ident_incr('EmployeeMst')  
end

exec usp_ID
select * from EmployeeMst 

alter procedure usp_userpassword
@password varchar(20),
@name varchar(20)

as
begin
SELECT  * FROM Admin   
update  EmployeeMst set Password = @password  where Name = @name
end
exec usp_userpassword 'Rash1' , 'Rashid'
sp_HelpText usp_User